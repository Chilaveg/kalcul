/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.9.5
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTextBrowser>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralWidget;
    QLabel *label;
    QPushButton *button_2;
    QPushButton *button_8;
    QPushButton *plus;
    QPushButton *button_6;
    QPushButton *button_3;
    QPushButton *rsc;
    QPushButton *AC;
    QPushButton *faktorial;
    QPushButton *button_9;
    QPushButton *button_7;
    QPushButton *button_5;
    QPushButton *lsc;
    QPushButton *button_1;
    QPushButton *buttonpow;
    QPushButton *button_0;
    QPushButton *button_4;
    QPushButton *ravno;
    QPushButton *delenie;
    QPushButton *umnozhit;
    QPushButton *minus;
    QPushButton *tochka;
    QPushButton *RC;
    QTextBrowser *textBrowser;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QStringLiteral("MainWindow"));
        MainWindow->setEnabled(true);
        MainWindow->resize(920, 480);
        QSizePolicy sizePolicy(QSizePolicy::Preferred, QSizePolicy::Preferred);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(MainWindow->sizePolicy().hasHeightForWidth());
        MainWindow->setSizePolicy(sizePolicy);
        MainWindow->setMinimumSize(QSize(920, 480));
        MainWindow->setMaximumSize(QSize(920, 480));
        centralWidget = new QWidget(MainWindow);
        centralWidget->setObjectName(QStringLiteral("centralWidget"));
        centralWidget->setEnabled(true);
        sizePolicy.setHeightForWidth(centralWidget->sizePolicy().hasHeightForWidth());
        centralWidget->setSizePolicy(sizePolicy);
        centralWidget->setMinimumSize(QSize(0, 0));
        centralWidget->setMaximumSize(QSize(920, 480));
        label = new QLabel(centralWidget);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(0, 0, 921, 80));
        QSizePolicy sizePolicy1(QSizePolicy::Maximum, QSizePolicy::Maximum);
        sizePolicy1.setHorizontalStretch(100);
        sizePolicy1.setVerticalStretch(100);
        sizePolicy1.setHeightForWidth(label->sizePolicy().hasHeightForWidth());
        label->setSizePolicy(sizePolicy1);
        label->setMaximumSize(QSize(16777215, 80));
        QFont font;
        font.setPointSize(25);
        label->setFont(font);
        label->setMouseTracking(false);
        label->setStyleSheet(QLatin1String("QLabel {\n"
"  qproperty-alignment: 'AlignVCenter | AlignRight';\n"
"  border: 1px solid gray;\n"
"}\n"
"\n"
"background-color : white;"));
        label->setInputMethodHints(Qt::ImhNone);
        label->setWordWrap(true);
        button_2 = new QPushButton(centralWidget);
        button_2->setObjectName(QStringLiteral("button_2"));
        button_2->setGeometry(QRect(600, 320, 80, 80));
        QSizePolicy sizePolicy2(QSizePolicy::Maximum, QSizePolicy::Maximum);
        sizePolicy2.setHorizontalStretch(0);
        sizePolicy2.setVerticalStretch(0);
        sizePolicy2.setHeightForWidth(button_2->sizePolicy().hasHeightForWidth());
        button_2->setSizePolicy(sizePolicy2);
        QFont font1;
        font1.setPointSize(20);
        button_2->setFont(font1);
        button_2->setStyleSheet(QLatin1String("QPushButton {\n"
"   border: 1px solid gray;\n"
"}\n"
"QPushButton:pressed {\n"
"    background-color: qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1,\n"
"                                      stop: 0 #dadbde, stop: 1 #f6f7fa);\n"
"}"));
        button_8 = new QPushButton(centralWidget);
        button_8->setObjectName(QStringLiteral("button_8"));
        button_8->setGeometry(QRect(600, 160, 80, 80));
        sizePolicy2.setHeightForWidth(button_8->sizePolicy().hasHeightForWidth());
        button_8->setSizePolicy(sizePolicy2);
        button_8->setFont(font1);
        button_8->setStyleSheet(QLatin1String("QPushButton {\n"
"   border: 1px solid gray;\n"
"}\n"
"QPushButton:pressed {\n"
"    background-color: qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1,\n"
"                                      stop: 0 #dadbde, stop: 1 #f6f7fa);\n"
"}"));
        plus = new QPushButton(centralWidget);
        plus->setObjectName(QStringLiteral("plus"));
        plus->setGeometry(QRect(760, 320, 80, 80));
        sizePolicy2.setHeightForWidth(plus->sizePolicy().hasHeightForWidth());
        plus->setSizePolicy(sizePolicy2);
        plus->setFont(font1);
        plus->setStyleSheet(QLatin1String("QPushButton {\n"
"  background-color: rgb(255, 151, 57);\n"
"  color: white; \n"
"  border: 1px solid gray;\n"
"}\n"
"\n"
"QPushButton:pressed {\n"
"    background-color: qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1,\n"
"                                      stop: 0 #FF7832, stop: 1 #FF9739);\n"
"}"));
        button_6 = new QPushButton(centralWidget);
        button_6->setObjectName(QStringLiteral("button_6"));
        button_6->setGeometry(QRect(680, 240, 80, 80));
        sizePolicy2.setHeightForWidth(button_6->sizePolicy().hasHeightForWidth());
        button_6->setSizePolicy(sizePolicy2);
        button_6->setFont(font1);
        button_6->setStyleSheet(QLatin1String("QPushButton {\n"
"   border: 1px solid gray;\n"
"}\n"
"QPushButton:pressed {\n"
"    background-color: qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1,\n"
"                                      stop: 0 #dadbde, stop: 1 #f6f7fa);\n"
"}"));
        button_3 = new QPushButton(centralWidget);
        button_3->setObjectName(QStringLiteral("button_3"));
        button_3->setGeometry(QRect(680, 320, 80, 80));
        sizePolicy2.setHeightForWidth(button_3->sizePolicy().hasHeightForWidth());
        button_3->setSizePolicy(sizePolicy2);
        button_3->setFont(font1);
        button_3->setStyleSheet(QLatin1String("QPushButton {\n"
"   border: 1px solid gray;\n"
"}\n"
"QPushButton:pressed {\n"
"    background-color: qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1,\n"
"                                      stop: 0 #dadbde, stop: 1 #f6f7fa);\n"
"}"));
        rsc = new QPushButton(centralWidget);
        rsc->setObjectName(QStringLiteral("rsc"));
        rsc->setGeometry(QRect(840, 280, 81, 200));
        sizePolicy2.setHeightForWidth(rsc->sizePolicy().hasHeightForWidth());
        rsc->setSizePolicy(sizePolicy2);
        rsc->setFont(font1);
        rsc->setStyleSheet(QLatin1String("QPushButton {\n"
"  background-color: rgb(255, 151, 57);\n"
"  color: white; \n"
"  border: 1px solid gray;\n"
"}\n"
"\n"
"QPushButton:pressed {\n"
"    background-color: qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1,\n"
"                                      stop: 0 #FF7832, stop: 1 #FF9739);\n"
"}"));
        AC = new QPushButton(centralWidget);
        AC->setObjectName(QStringLiteral("AC"));
        AC->setGeometry(QRect(559, 80, 41, 80));
        sizePolicy2.setHeightForWidth(AC->sizePolicy().hasHeightForWidth());
        AC->setSizePolicy(sizePolicy2);
        AC->setFont(font1);
        AC->setStyleSheet(QLatin1String("QPushButton {\n"
"  background-color: rgb(215, 215, 215);\n"
"  border: 1px solid gray;\n"
"}\n"
"QPushButton:pressed {\n"
"    background-color: qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1,\n"
"                                      stop: 0 #BEBEBE, stop: 1 #D7D7D7);\n"
"}"));
        faktorial = new QPushButton(centralWidget);
        faktorial->setObjectName(QStringLiteral("faktorial"));
        faktorial->setGeometry(QRect(600, 80, 80, 80));
        sizePolicy2.setHeightForWidth(faktorial->sizePolicy().hasHeightForWidth());
        faktorial->setSizePolicy(sizePolicy2);
        faktorial->setFont(font1);
        faktorial->setStyleSheet(QLatin1String("QPushButton {\n"
"  background-color: rgb(215, 215, 215);\n"
"  border: 1px solid gray;\n"
"}\n"
"QPushButton:pressed {\n"
"    background-color: qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1,\n"
"                                      stop: 0 #BEBEBE, stop: 1 #D7D7D7);\n"
"}"));
        button_9 = new QPushButton(centralWidget);
        button_9->setObjectName(QStringLiteral("button_9"));
        button_9->setGeometry(QRect(680, 160, 80, 80));
        sizePolicy2.setHeightForWidth(button_9->sizePolicy().hasHeightForWidth());
        button_9->setSizePolicy(sizePolicy2);
        button_9->setFont(font1);
        button_9->setStyleSheet(QLatin1String("QPushButton {\n"
"   border: 1px solid gray;\n"
"}\n"
"QPushButton:pressed {\n"
"    background-color: qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1,\n"
"                                      stop: 0 #dadbde, stop: 1 #f6f7fa);\n"
"}"));
        button_7 = new QPushButton(centralWidget);
        button_7->setObjectName(QStringLiteral("button_7"));
        button_7->setGeometry(QRect(520, 160, 80, 80));
        sizePolicy2.setHeightForWidth(button_7->sizePolicy().hasHeightForWidth());
        button_7->setSizePolicy(sizePolicy2);
        button_7->setFont(font1);
        button_7->setStyleSheet(QLatin1String("QPushButton {\n"
"   border: 1px solid gray;\n"
"}\n"
"QPushButton:pressed {\n"
"    background-color: qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1,\n"
"                                      stop: 0 #dadbde, stop: 1 #f6f7fa);\n"
"}"));
        button_5 = new QPushButton(centralWidget);
        button_5->setObjectName(QStringLiteral("button_5"));
        button_5->setGeometry(QRect(600, 240, 80, 80));
        sizePolicy2.setHeightForWidth(button_5->sizePolicy().hasHeightForWidth());
        button_5->setSizePolicy(sizePolicy2);
        button_5->setFont(font1);
        button_5->setStyleSheet(QLatin1String("QPushButton {\n"
"   border: 1px solid gray;\n"
"}\n"
"QPushButton:pressed {\n"
"    background-color: qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1,\n"
"                                      stop: 0 #dadbde, stop: 1 #f6f7fa);\n"
"}"));
        lsc = new QPushButton(centralWidget);
        lsc->setObjectName(QStringLiteral("lsc"));
        lsc->setGeometry(QRect(840, 80, 81, 201));
        sizePolicy2.setHeightForWidth(lsc->sizePolicy().hasHeightForWidth());
        lsc->setSizePolicy(sizePolicy2);
        lsc->setFont(font1);
        lsc->setStyleSheet(QLatin1String("QPushButton {\n"
"  background-color: rgb(255, 151, 57);\n"
"  color: white; \n"
"  border: 1px solid gray;\n"
"}\n"
"\n"
"QPushButton:pressed {\n"
"    background-color: qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1,\n"
"                                      stop: 0 #FF7832, stop: 1 #FF9739);\n"
"}"));
        button_1 = new QPushButton(centralWidget);
        button_1->setObjectName(QStringLiteral("button_1"));
        button_1->setGeometry(QRect(520, 320, 80, 80));
        sizePolicy2.setHeightForWidth(button_1->sizePolicy().hasHeightForWidth());
        button_1->setSizePolicy(sizePolicy2);
        button_1->setFont(font1);
        button_1->setStyleSheet(QLatin1String("QPushButton {\n"
"   border: 1px solid gray;\n"
"}\n"
"QPushButton:pressed {\n"
"    background-color: qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1,\n"
"                                      stop: 0 #dadbde, stop: 1 #f6f7fa);\n"
"}"));
        buttonpow = new QPushButton(centralWidget);
        buttonpow->setObjectName(QStringLiteral("buttonpow"));
        buttonpow->setGeometry(QRect(680, 80, 80, 80));
        sizePolicy2.setHeightForWidth(buttonpow->sizePolicy().hasHeightForWidth());
        buttonpow->setSizePolicy(sizePolicy2);
        buttonpow->setFont(font1);
        buttonpow->setStyleSheet(QLatin1String("QPushButton {\n"
"  background-color: rgb(215, 215, 215);\n"
"  border: 1px solid gray;\n"
"}\n"
"QPushButton:pressed {\n"
"    background-color: qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1,\n"
"                                      stop: 0 #BEBEBE, stop: 1 #D7D7D7);\n"
"}"));
        button_0 = new QPushButton(centralWidget);
        button_0->setObjectName(QStringLiteral("button_0"));
        button_0->setGeometry(QRect(520, 400, 161, 80));
        sizePolicy2.setHeightForWidth(button_0->sizePolicy().hasHeightForWidth());
        button_0->setSizePolicy(sizePolicy2);
        button_0->setFont(font1);
        button_0->setStyleSheet(QLatin1String("QPushButton {\n"
"   border: 1px solid gray;\n"
"}\n"
"QPushButton:pressed {\n"
"    background-color: qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1,\n"
"                                      stop: 0 #dadbde, stop: 1 #f6f7fa);\n"
"}"));
        button_4 = new QPushButton(centralWidget);
        button_4->setObjectName(QStringLiteral("button_4"));
        button_4->setGeometry(QRect(520, 240, 80, 80));
        sizePolicy2.setHeightForWidth(button_4->sizePolicy().hasHeightForWidth());
        button_4->setSizePolicy(sizePolicy2);
        button_4->setFont(font1);
        button_4->setStyleSheet(QLatin1String("QPushButton {\n"
"   border: 1px solid gray;\n"
"}\n"
"QPushButton:pressed {\n"
"    background-color: qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1,\n"
"                                      stop: 0 #dadbde, stop: 1 #f6f7fa);\n"
"}"));
        ravno = new QPushButton(centralWidget);
        ravno->setObjectName(QStringLiteral("ravno"));
        ravno->setGeometry(QRect(760, 400, 80, 80));
        sizePolicy2.setHeightForWidth(ravno->sizePolicy().hasHeightForWidth());
        ravno->setSizePolicy(sizePolicy2);
        ravno->setFont(font1);
        ravno->setStyleSheet(QLatin1String("QPushButton {\n"
"  background-color: rgb(255, 151, 57);\n"
"  color: white; \n"
"  border: 1px solid gray;\n"
"}\n"
"\n"
"QPushButton:pressed {\n"
"    background-color: qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1,\n"
"                                      stop: 0 #FF7832, stop: 1 #FF9739);\n"
"}"));
        delenie = new QPushButton(centralWidget);
        delenie->setObjectName(QStringLiteral("delenie"));
        delenie->setGeometry(QRect(760, 80, 81, 80));
        sizePolicy2.setHeightForWidth(delenie->sizePolicy().hasHeightForWidth());
        delenie->setSizePolicy(sizePolicy2);
        delenie->setFont(font1);
        delenie->setStyleSheet(QLatin1String("QPushButton {\n"
"  background-color: rgb(255, 151, 57);\n"
"  color: white; \n"
"  border: 1px solid gray;\n"
"}\n"
"\n"
"QPushButton:pressed {\n"
"    background-color: qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1,\n"
"                                      stop: 0 #FF7832, stop: 1 #FF9739);\n"
"}"));
        umnozhit = new QPushButton(centralWidget);
        umnozhit->setObjectName(QStringLiteral("umnozhit"));
        umnozhit->setGeometry(QRect(760, 160, 80, 80));
        sizePolicy2.setHeightForWidth(umnozhit->sizePolicy().hasHeightForWidth());
        umnozhit->setSizePolicy(sizePolicy2);
        umnozhit->setFont(font1);
        umnozhit->setStyleSheet(QLatin1String("QPushButton {\n"
"  background-color: rgb(255, 151, 57);\n"
"  color: white; \n"
"  border: 1px solid gray;\n"
"}\n"
"\n"
"QPushButton:pressed {\n"
"    background-color: qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1,\n"
"                                      stop: 0 #FF7832, stop: 1 #FF9739);\n"
"}"));
        minus = new QPushButton(centralWidget);
        minus->setObjectName(QStringLiteral("minus"));
        minus->setGeometry(QRect(760, 240, 80, 80));
        sizePolicy2.setHeightForWidth(minus->sizePolicy().hasHeightForWidth());
        minus->setSizePolicy(sizePolicy2);
        minus->setFont(font1);
        minus->setStyleSheet(QLatin1String("QPushButton {\n"
"  background-color: rgb(255, 151, 57);\n"
"  color: white; \n"
"  border: 1px solid gray;\n"
"}\n"
"\n"
"QPushButton:pressed {\n"
"    background-color: qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1,\n"
"                                      stop: 0 #FF7832, stop: 1 #FF9739);\n"
"}"));
        tochka = new QPushButton(centralWidget);
        tochka->setObjectName(QStringLiteral("tochka"));
        tochka->setGeometry(QRect(680, 400, 80, 80));
        sizePolicy2.setHeightForWidth(tochka->sizePolicy().hasHeightForWidth());
        tochka->setSizePolicy(sizePolicy2);
        tochka->setFont(font1);
        tochka->setStyleSheet(QLatin1String("QPushButton {\n"
"  background-color: rgb(215, 215, 215);\n"
"  border: 1px solid gray;\n"
"}\n"
"QPushButton:pressed {\n"
"    background-color: qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1,\n"
"                                      stop: 0 #BEBEBE, stop: 1 #D7D7D7);\n"
"}"));
        RC = new QPushButton(centralWidget);
        RC->setObjectName(QStringLiteral("RC"));
        RC->setGeometry(QRect(520, 80, 41, 80));
        sizePolicy2.setHeightForWidth(RC->sizePolicy().hasHeightForWidth());
        RC->setSizePolicy(sizePolicy2);
        RC->setFont(font1);
        RC->setStyleSheet(QLatin1String("QPushButton {\n"
"  background-color: rgb(215, 215, 215);\n"
"  border: 1px solid gray;\n"
"}\n"
"QPushButton:pressed {\n"
"    background-color: qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1,\n"
"                                      stop: 0 #BEBEBE, stop: 1 #D7D7D7);\n"
"}"));
        textBrowser = new QTextBrowser(centralWidget);
        textBrowser->setObjectName(QStringLiteral("textBrowser"));
        textBrowser->setGeometry(QRect(0, 80, 525, 402));
        MainWindow->setCentralWidget(centralWidget);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "MainWindow", Q_NULLPTR));
        label->setText(QString());
        button_2->setText(QApplication::translate("MainWindow", "2", Q_NULLPTR));
        button_8->setText(QApplication::translate("MainWindow", "8", Q_NULLPTR));
        plus->setText(QApplication::translate("MainWindow", "+", Q_NULLPTR));
        button_6->setText(QApplication::translate("MainWindow", "6", Q_NULLPTR));
        button_3->setText(QApplication::translate("MainWindow", "3", Q_NULLPTR));
        rsc->setText(QApplication::translate("MainWindow", ")", Q_NULLPTR));
        AC->setText(QApplication::translate("MainWindow", "AC", Q_NULLPTR));
        faktorial->setText(QApplication::translate("MainWindow", "!", Q_NULLPTR));
        button_9->setText(QApplication::translate("MainWindow", "9", Q_NULLPTR));
        button_7->setText(QApplication::translate("MainWindow", "7", Q_NULLPTR));
        button_5->setText(QApplication::translate("MainWindow", "5", Q_NULLPTR));
        lsc->setText(QApplication::translate("MainWindow", "(", Q_NULLPTR));
        button_1->setText(QApplication::translate("MainWindow", "1", Q_NULLPTR));
        buttonpow->setText(QApplication::translate("MainWindow", "x^y", Q_NULLPTR));
        button_0->setText(QApplication::translate("MainWindow", "0", Q_NULLPTR));
        button_4->setText(QApplication::translate("MainWindow", "4", Q_NULLPTR));
        ravno->setText(QApplication::translate("MainWindow", "=", Q_NULLPTR));
        delenie->setText(QApplication::translate("MainWindow", "/", Q_NULLPTR));
        umnozhit->setText(QApplication::translate("MainWindow", "*", Q_NULLPTR));
        minus->setText(QApplication::translate("MainWindow", "-", Q_NULLPTR));
        tochka->setText(QApplication::translate("MainWindow", ".", Q_NULLPTR));
        RC->setText(QApplication::translate("MainWindow", "RC", Q_NULLPTR));
        textBrowser->setHtml(QApplication::translate("MainWindow", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'Ubuntu'; font-size:11pt; font-weight:400; font-style:normal;\">\n"
"<p align=\"center\" style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-size:16pt; font-weight:600; text-decoration: underline;\">\320\241\320\277\321\200\320\260\320\262\320\272\320\260 \320\277\320\276 \321\200\320\260\320\261\320\276\321\202\320\265 \321\201 \320\277\321\200\320\276\320\263\321\200\320\260\320\274\320\274\320\276\320\271:</span></p>\n"
"<p align=\"center\" style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:16pt; font-weight:600; text-decoration: underline;\"><br /></p>\n"
"<p styl"
                        "e=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-size:16pt;\">* \320\232\320\273\320\260\320\262\320\270\321\210\320\260 RC \321\201\321\202\320\270\321\200\320\260\320\265\321\202 \320\276\320\264\320\270\320\275 \321\201\320\270\320\274\320\262\320\276\320\273 \321\201\320\277\321\200\320\260\320\262\320\276\320\271 \321\201\321\202\320\276\321\200\320\276\320\275\321\213.</span></p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-size:16pt;\">* \320\232\320\273\320\260\320\262\320\270\321\210\320\260 AC \320\276\321\207\320\270\321\211\320\260\320\265\321\202 \320\277\320\276\320\273\320\265 \320\262\320\262\320\276\320\264\320\260 \320\262\321\213\321\200\320\260\320\266\320\265\320\275\320\270\320\271.</span></p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-inde"
                        "nt:0px;\"><span style=\" font-size:16pt;\">* \320\237\321\200\320\270 \321\203\320\274\320\275\320\276\320\266\320\265\320\275\320\270\320\270, \320\264\320\265\320\273\320\265\320\275\320\270\320\270, \320\262\320\276\320\267\320\262\320\265\320\264\320\265\320\275\320\270\320\270 \320\262 \321\201\321\202\320\265\320\277\320\265\320\275\321\214, \321\201\321\203\320\274\320\274\320\270\321\200\320\276\320\262\320\260\320\275\320\270\320\270 \320\276\321\202\321\200\320\270\321\206\320\260\321\202\320\265\320\273\321\214\320\275\321\213\320\265 \321\207\320\270\321\201\320\273\320\260 \320\264\320\276\320\273\320\266\320\275\321\213 \320\261\321\213\321\202\321\214 \320\262\320\275\320\265\321\201\320\265\320\275\321\213 \320\262 \321\201\320\272\320\276\320\261\320\272\320\270.</span></p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-size:16pt;\">* \320\247\320\270\321\201\320\273\320\276, \321\204\320\260\320\272"
                        "\321\202\320\276\321\200\320\270\320\260\320\273 \320\272\320\276\321\202\320\276\321\200\320\276\320\263\320\276 \320\262\321\213 \321\205\320\276\321\202\320\270\321\202\320\265 \320\275\320\260\320\271\321\202\320\270 \320\264\320\276\320\273\320\266\320\275\320\276 \320\261\321\213\321\202\321\214 &gt;= 0.</span></p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-size:16pt;\">** \320\237\321\200\320\270\320\274\320\265\321\207\320\260\320\275\320\270\320\265: \320\277\321\200\320\270 \320\277\320\276\320\277\321\213\321\202\320\272\320\265 \320\277\320\276\321\201\321\207\320\270\321\202\320\260\321\202\321\214 \321\204\320\260\320\272\321\202\320\276\321\200\320\270\320\260\320\273 \320\264\321\200\320\276\320\261\320\275\320\276\320\263\320\276 \321\207\320\270\321\201\320\273\320\260, \321\207\320\270\321\201\320\273\320\276 \320\261\321\203\320\264\320\265\321\202 \320\276\320\272\321\200\321\203\320\263\320"
                        "\273\321\217\321\202\321\214\321\201\321\217 \320\262 \320\274\320\265\320\275\321\214\321\210\321\203\321\216 \321\201\321\202\320\276\321\200\320\276\320\275\321\203 \320\270 \320\277\320\276\321\201\320\273\320\265 \321\215\321\202\320\276\320\263\320\276 \320\275\320\260\321\205\320\276\320\264\320\270\321\202\321\214\321\201\321\217 \321\204\320\260\320\272\321\202\320\276\321\200\320\270\320\260\320\273</span></p></body></html>", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
