/********************************************************************************
** Form generated from reading UI file 'gendalf.ui'
**
** Created by: Qt User Interface Compiler version 5.9.5
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_GENDALF_H
#define UI_GENDALF_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>

QT_BEGIN_NAMESPACE

class Ui_gendalf
{
public:
    QLabel *label;
    QLabel *label_2;

    void setupUi(QDialog *gendalf)
    {
        if (gendalf->objectName().isEmpty())
            gendalf->setObjectName(QStringLiteral("gendalf"));
        gendalf->resize(478, 237);
        label = new QLabel(gendalf);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(0, 0, 481, 241));
        label->setPixmap(QPixmap(QString::fromUtf8("../../\320\227\320\260\320\263\321\200\321\203\320\267\320\272\320\270/1513797550111965969.jpg")));
        label->setScaledContents(false);
        label->setOpenExternalLinks(false);
        label_2 = new QLabel(gendalf);
        label_2->setObjectName(QStringLiteral("label_2"));
        label_2->setGeometry(QRect(10, 170, 471, 101));
        QFont font;
        font.setPointSize(22);
        font.setBold(true);
        font.setUnderline(false);
        font.setWeight(75);
        label_2->setFont(font);
        label_2->setStyleSheet(QStringLiteral("color: rgb(238, 238, 236);"));

        retranslateUi(gendalf);

        QMetaObject::connectSlotsByName(gendalf);
    } // setupUi

    void retranslateUi(QDialog *gendalf)
    {
        gendalf->setWindowTitle(QApplication::translate("gendalf", "\320\222\320\276\320\276\321\200\321\203\320\266\320\265\320\275\320\275\321\213\320\271 \321\201\321\202\320\260\321\200\320\270\320\272, \320\273\321\203\321\207\321\210\320\265 \320\265\320\263\320\276 \320\277\320\276\321\201\320\273\321\203\321\210\320\260\321\202\321\214", Q_NULLPTR));
        label->setText(QString());
        label_2->setText(QApplication::translate("gendalf", "\320\243\320\274\320\265\320\275\321\214\321\210\320\270\321\202\320\265 \321\200\320\260\320\267\320\274\320\265\321\200 \320\262\321\213\321\200\320\260\320\266\320\265\320\275\320\270\321\217", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class gendalf: public Ui_gendalf {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_GENDALF_H
