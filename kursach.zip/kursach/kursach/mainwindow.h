#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{

    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();

private slots:


private:
    Ui::MainWindow *ui;


private slots:
    void digits();
    void on_tochka_clicked();
    void on_AC_clicked();
    void on_ravno_clicked();
    void step();
    void on_RC_clicked();
    void on_buttonpow_clicked();
    void on_faktorial_clicked();
    void operations();
};

#endif // MAINWINDOW_H
