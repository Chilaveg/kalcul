#include "gendalf.h"
#include "ui_gendalf.h"

gendalf::gendalf(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::gendalf)
{
    ui->setupUi(this);
}

gendalf::~gendalf()
{
    delete ui;
}
