#include "mainwindow.h"
#include <QApplication>
#include "math.h"
#include <iostream>
int main(int argc, char *argv[])
{
using namespace std;
    QApplication a(argc, argv);
    MainWindow w;
    w.show();
    return a.exec();
}
