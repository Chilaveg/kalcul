#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "string.h"
#include "math.h"
#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <QMessageBox>
#include <qicon.h>
#include <gendalf.h>

using namespace std;
long double c,a,b,res;
long double d,num;
int i;
char ch;
int oshibka=0;
// 0 - ок
// 1 - деление на 0
// 2 - неверный факториал
// 3 - скобки гг
// 4 - выражение гг
// 5 - 0 в 0
// 6 - большие числа
typedef struct data
{
        long double numb;
        char op;
        struct data *next;
} St;

St buf;

void shit(int oshibka)
{
    if (oshibka == 1)
    {
        QMessageBox::critical(NULL, QObject::tr("ERROR"), QObject::tr("ОШИБКА, на ноль делить нельзя"));
    }
    if (oshibka == 2)
    {
        QMessageBox::critical(NULL, QObject::tr("ERROR"), QObject::tr("Факториал числа не может быть отрицательным"));
    }
    if (oshibka == 3)
    {
        QMessageBox::critical(NULL, QObject::tr("ERROR"), QObject::tr("Ошибка ввода скобок, попробуйте еще раз"));
    }
    if (oshibka == 4)
    {
        QMessageBox::critical(NULL, QObject::tr("ERROR"), QObject::tr("Ошибка, неверно введено выражение"));
    }
    if (oshibka == 5)
    {
        QMessageBox::critical(NULL, QObject::tr("ERROR"), QObject::tr("Ошибка, ноль в нулевой степени не определен"));
    }

    if (oshibka == 6)
    {
        QMessageBox::critical(NULL, QObject::tr("ERROR"), QObject::tr("Введите числа поменьше"));
    }
    else oshibka = 0;

}

long double fact(int N)
{
    if(N < 0) // если пользователь ввел отрицательное число
    {
        shit(2);
        return 0;
    }   // возвращаем ноль
    if (N == 0) // если пользователь ввел ноль,
        return 1; // возвращаем факториал от нуля, это 1
    else // Во всех остальных случаях
        return N * fact(N - 1); // делаем рекурсию.
}

St* push(St *head,long double numb, char op)
{
    St *new_elem;
    new_elem = (St*)malloc(sizeof(St));
    new_elem->numb = numb;
    new_elem->op = op;
    if(head == NULL)
    {
        head = new_elem;
        new_elem->next = NULL;
    }
    else
    {
        new_elem->next = head;
        head = new_elem;
    }
    return head;
}

St* pop(St *head)
{
    St *cur;
    if(head == NULL) return NULL;
    cur = head;
    head = head->next;
    buf.next = head;
    buf.numb = cur->numb;
    buf.op = cur->op;
    free(cur);
    return head;
}

St* push_back(St *head, long double numb, char op)
{
    St *new_elem,*cur;
    new_elem = (St*)malloc(sizeof(St));
    new_elem->numb = numb;
    new_elem->op = op;
    if(head == NULL)
    {
        head = new_elem;
        new_elem->next = NULL;
    }
    else
    {
        cur = head;
        while(cur->next != NULL)
        {
            cur = cur->next;
        }
        cur->next = new_elem;
        new_elem->next = NULL;
    }
    return head;
}

int priorOp(char op)
{
    if(op == '+' || op == '-') return 1;
    if(op == '*' || op == '/') return 2;
    if(op == '^') return 3;
    if(op == '!') return 4;
    return 0;
}

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    QMessageBox::information(this,"О программе", "Программа - калькулятор, сделано студентом группы Э-57 Гайдуком Алексеем.",QMessageBox::Ok);
    ui->setupUi(this);
    this->setWindowTitle("Калькулятор");
    connect(ui->button_0,SIGNAL(clicked()),this,SLOT(digits()));
    connect(ui->button_1,SIGNAL(clicked()),this,SLOT(digits()));
    connect(ui->button_2,SIGNAL(clicked()),this,SLOT(digits()));
    connect(ui->button_3,SIGNAL(clicked()),this,SLOT(digits()));
    connect(ui->button_4,SIGNAL(clicked()),this,SLOT(digits()));
    connect(ui->button_5,SIGNAL(clicked()),this,SLOT(digits()));
    connect(ui->button_6,SIGNAL(clicked()),this,SLOT(digits()));
    connect(ui->button_7,SIGNAL(clicked()),this,SLOT(digits()));
    connect(ui->button_8,SIGNAL(clicked()),this,SLOT(digits()));
    connect(ui->button_9,SIGNAL(clicked()),this,SLOT(digits()));
    connect(ui->lsc,SIGNAL(clicked()),this,SLOT(operations()));
    connect(ui->plus,SIGNAL(clicked()),this,SLOT(operations()));
    connect(ui->minus,SIGNAL(clicked()),this,SLOT(operations()));
    connect(ui->delenie,SIGNAL(clicked()),this,SLOT(operations()));
    connect(ui->umnozhit,SIGNAL(clicked()),this,SLOT(operations()));
    connect(ui->rsc,SIGNAL(clicked()),this,SLOT(operations()));

}

MainWindow::~MainWindow()
{

    delete ui;
}

void MainWindow::digits()
{
    if (ui->label->text().size() >= 45)
    {
        gendalf window;
        window.setModal(true);
        window.exec();
        return;
    }
    QPushButton *button = (QPushButton *)sender();
    QString string;
    string = (ui->label->text() + button->text());
    ui->label->setText(string);
}

void MainWindow::operations()
{
    if (ui->label->text().size() >= 45)
    {
        gendalf window;
        window.setModal(true);
        window.exec();
        return;
    }
    QPushButton *button = (QPushButton *)sender();
    QString string;
    string = (ui->label->text() + button->text());
    ui->label->setText(string);
    MainWindow::ui->tochka->setEnabled(true);
}

void MainWindow::step()
{
    if (ui->label->text().size() >= 45)
    {
        gendalf window;
        window.setModal(true);
        window.exec();
        return;
    }
    QString string;
    string = (ui->label->text() + "^");
    ui->label->setText(string);
    MainWindow::ui->tochka->setEnabled(true);
}

void MainWindow::on_tochka_clicked()
{
    if (ui->label->text().size() >= 45)
    {
        gendalf window;
        window.setModal(true);
        window.exec();
        return;
    }
    MainWindow::ui->tochka->setEnabled(false);
    ui->label->setText(ui->label->text() + ".");
}

void MainWindow::on_AC_clicked()
{
    ui->label->setText("");
    MainWindow::ui->tochka->setEnabled(true);
}

void MainWindow::on_ravno_clicked()
{
    char cel[10000],drob[10000];
    QString res;
    int ind,slen,i;
    long double numb;
    St *head = NULL;
    St *resStr = NULL;
    if (ui->label->text() == "") return; // антикриворучка
    res=("(" + ui->label->text() + ")");
    QByteArray s = res.toLocal8Bit();
    std::string ba = std::string(s.data(), s.size());
    int rscb = 0,lscb = 0,a1,b1,c1,n,t = 0,ch = 0;
    a1 = strlen(s);
    for (i=0;i < a1;i++)
    {
        if (s[i] == '(') lscb++;
        if (s[i] == ')') rscb++;
    }
    if (lscb != rscb)
    {
        oshibka = 3;
        shit(oshibka);
        oshibka = 0;
        return;
    }
    for (i = 0;i < a1;i++)
        {
            if ((s[i] == '(') && (s[i+1] == '-') && (lscb == rscb))
            {
                n++;
            }
        }
        for (i = 0;i < a1+n;i++)
        {
            if ((s[i] == '(') && (s[i+1] == '-') && (lscb == rscb))
            {
                b1 = i;
                t++;
                for (c1 = a1 + t;c1 > b1;c1--)
                {
                    s[c1] = s[c1 - 1];
                }
                s[b1 + 1] = '0';
             }
        }
        for (i = 0;i < a1;i++)
            {
                if ((s[i] == '1' || s[i] == '2' || s[i] == '3' || s[i] == '4' || s[i] == '5' ||
                     s[i] == '6' || s[i] == '7' || s[i] == '8' || s[i] == '9' || s[i] == '0') && (s[i+1] == '('))
                {
                    n++;
                }
            }
            for (i = 0;i < a1+n;i++)
            {
                if ((s[i] == '1' || s[i] == '2' || s[i] == '3' || s[i] == '4' || s[i] == '5' ||
                     s[i] == '6' || s[i] == '7' || s[i] == '8' || s[i] == '9' || s[i] == '0') && (s[i+1] == '('))
                {
                    b1 = i;
                    t++;
                    for (c1 = a1 + t;c1 > b1;c1--)
                    {
                        s[c1] = s[c1 - 1];
                    }
                    s[b1 + 1] = '*';
                 }
            }
            for (i = 0;i < a1;i++)
                {
                    if ((s[i+1] == '1' || s[i+1] == '2' || s[i+1] == '3' || s[i+1] == '4' ||
                         s[i+1] == '5' || s[i+1] == '6' || s[i+1] == '7' || s[i+1] == '8' || s[i+1] == '9' || s[i+1] == '0') && (s[i] == ')'))
                    {
                        n++;
                    }
                }
                for (i = 0;i < a1+n;i++)
                {
                    if ((s[i+1] == '1' || s[i+1] == '2' || s[i+1] == '3' || s[i+1] == '4' ||
                         s[i+1] == '5' || s[i+1] == '6' || s[i+1] == '7' || s[i+1] == '8' || s[i+1] == '9' || s[i+1] == '0') && (s[i] == ')'))
                    {
                        b1 = i;
                        t++;
                        for (c1 = a1 + t;c1 > b1;c1--)
                        {
                            s[c1] = s[c1 - 1];
                        }
                        s[b1 + 1] = '*';
                     }
                }
        //    s[i] == ')') && (s[i+1] == '1' || s[i+1] == '2' || s[i+1] == '3' || s[i+1] == '4' ||
          //                  s[i+1] == '5' || s[i+1] == '6' || s[i+1] == '7' || s[i+1] == '8' || s[i+1] == '9' || s[i+1] == '0'

        for (i = 0;i < a1;i++)
        {
            if (((s[i] == '!') && (s[i + 1] == '^')) || ((s[i] == '!') && (s[i + 1] == '/')) ||
                ((s[i] == '!') && (s[i + 1] == '*')) || ((s[i] == '!') && (s[i + 1] == '-')) ||
                ((s[i] == '!') && (s[i + 1] == '(')) || ((s[i] == '!') && (s[i + 1] == '+')) ||
                ((s[i] == '!') && (s[i + 1] == '.')) || ((s[i] == '^') && (s[i + 1] == '!')) ||
                ((s[i] == '^') && (s[i + 1] == '/')) || ((s[i] == '^') && (s[i + 1] == '+')) ||
                ((s[i] == '^') && (s[i + 1] == ')')) || ((s[i] == '^') && (s[i + 1] == '-')) ||
                ((s[i] == '/') && (s[i + 1] == '!')) || ((s[i] == '/') && (s[i + 1] == '^')) ||
                ((s[i] == '/') && (s[i + 1] == '/')) || ((s[i] == '/') && (s[i + 1] == '*')) ||
                ((s[i] == '/') && (s[i + 1] == '+')) || ((s[i] == '/') && (s[i + 1] == '-')) ||
                ((s[i] == '/') && (s[i + 1] == '.')) || ((s[i] == '/') && (s[i + 1] == ')')) ||
                ((s[i] == '(') && (s[i + 1] == '!')) || ((s[i] == '(') && (s[i + 1] == '^')) ||
                ((s[i] == '(') && (s[i + 1] == '*')) || ((s[i] == '(') && (s[i + 1] == '/')) ||
                ((s[i] == '(') && (s[i + 1] == '.')) || ((s[i] == '(') && (s[i + 1] == '+')) ||
                ((s[i] == '(') && (s[i + 1] == ')')) || ((s[i] == ')') && (s[i + 1] == '.')) ||
                ((s[i] == '*') && (s[i + 1] == '!')) || ((s[i] == '*') && (s[i + 1] == '^')) ||
                ((s[i] == '*') && (s[i + 1] == '/')) || ((s[i] == '*') && (s[i + 1] == '*')) ||
                ((s[i] == '*') && (s[i + 1] == ')')) || ((s[i] == '*') && (s[i + 1] == '-')) ||
                ((s[i] == '*') && (s[i + 1] == '+')) || ((s[i] == '*') && (s[i + 1] == '.')) ||
                ((s[i] == '-') && (s[i + 1] == '!')) || ((s[i] == '-') && (s[i + 1] == '^')) ||
                ((s[i] == '-') && (s[i + 1] == '/')) || ((s[i] == '-') && (s[i + 1] == '*')) ||
                ((s[i] == '-') && (s[i + 1] == '-')) || ((s[i] == '-') && (s[i + 1] == '+')) ||
                ((s[i] == '-') && (s[i + 1] == ')')) || ((s[i] == '-') && (s[i + 1] == '.')) ||
                ((s[i] == '+') && (s[i + 1] == '!')) || ((s[i] == '+') && (s[i + 1] == '^')) ||
                ((s[i] == '+') && (s[i + 1] == '/')) || ((s[i] == '+') && (s[i + 1] == '*')) ||
                ((s[i] == '+') && (s[i + 1] == '-')) || ((s[i] == '+') && (s[i + 1] == '+')) ||
                ((s[i] == '+') && (s[i + 1] == ')')) || ((s[i] == '+') && (s[i + 1] == '.')) ||
                ((s[i] == '.') && (s[i + 1] == '!')) || ((s[i] == '.') && (s[i + 1] == '^')) ||
                ((s[i] == '.') && (s[i + 1] == '/')) || ((s[i] == '.') && (s[i + 1] == '*')) ||
                ((s[i] == '.') && (s[i + 1] == '-')) || ((s[i] == '.') && (s[i + 1] == '+')) ||
                ((s[i] == '.') && (s[i + 1] == '(')) || ((s[i] == '.') && (s[i + 1] == ')')) ||
                ((s[i] == '.') && (s[i + 1] == '.')) || ((s[i] == '!') && (s[i + 1] == '!'))) // костыль
            {
                oshibka = 4;
                shit(oshibka);
                //ui->label->setText("");
                oshibka = 0;
                return;
            }

        }
        for (i = 0;i < a1;i++)
            {
                if (s[i] == '!')
                {
                    n++;
                }
            }
            for (i = 0;i < a1+n;i++)
            {
                if (s[i] == '!')
                {
                    b1 = i;
                    t++;
                    for (c1 = a1 + t;c1 > b1;c1--)
                    {
                        s[c1] = s[c1 - 1];
                    }
                    s[b1 + 1] = '0';
                 }
            }

        a1 = strlen(s);
        slen = strlen(s);
        i = 0;
        while(i < slen)
        {
            if(s[i] == '1' || s[i] == '2' || s[i] == '3' || s[i] == '4' || s[i] == '5' ||
            s[i] == '6' || s[i] == '7' || s[i] == '8' || s[i] == '9' || s[i] == '0')
            {
                strcpy(cel,"\0");
                strcpy(drob,"\0");
                ind = 0;
                while((s[i] == '1' || s[i] == '2' || s[i] == '3' || s[i] == '4' || s[i] == '5' ||
                s[i] == '6' || s[i] == '7' || s[i] == '8' || s[i] == '9' || s[i] == '0') && (i < slen))
                {
                    cel[ind] = s[i];
                    ind++;
                    i++;
                }
                cel[ind] = '\0';
                if(s[i] == '.')
                {
                    i++;
                    ind = 0;
                    while((s[i] == '1' || s[i] == '2' || s[i] == '3' || s[i] == '4' || s[i] == '5' ||
                          s[i] == '6' || s[i] == '7' || s[i] == '8' || s[i] == '9' || s[i] == '0') && (i<slen))
                    {
                        drob[ind] = s[i];
                        ind++;
                        i++;
                    }
                    drob[ind] = '\0';
                }
                numb = atof(cel) + atof(drob) / pow(10,strlen(drob));
                resStr = push_back(resStr,numb,0);
            }
            else
            {
                if(s[i] == '(') head = push(head,-1,s[i]);
                else if(s[i] == ')')
                {
                    while(head->op != '(')
                    {
                        resStr = push_back(resStr,-1,head->op);
                        head = pop(head);
                    }
                    if(head->op == '(') head = pop(head);
                }
                else if(s[i] == '+' || s[i] == '-' || s[i] == '*' || s[i] == '/' || s[i] == '^' || s[i] == '!')
                {
                    while(priorOp(s[i]) <= priorOp(head->op) && priorOp(head->op) != 0)
                    {
                         resStr = push_back(resStr,-1,head->op);
                         head = pop(head);
                    }
                    head = push(head,-1,s[i]);
                }
                i++;
            }
        }
        St *cur;
        cur = resStr;
        long double a,b;
        while(cur != NULL)
        {
            if(cur->numb < 0)
            {
                a = head->numb;
                head = pop(head);
                b = head->numb;
                head = pop(head);
                switch(cur->op)
                {
                    case '+':
                        head = push(head,b + a,0);
                        break;
                    case '-':
                        head = push(head,b - a,0);
                        break;
                    case '*':
                        head = push(head,b * a,0);
                        break;
                    case '/':
                        head = push(head,b / a,0);
                        if (a == 0)
                        {
                            oshibka = 1;
                            shit(oshibka);
                            oshibka = 0;
                            return;
                        }
                        break;
                    case '^':
                        if(a == 0 && b == 0)
                        {
                            oshibka = 5;
                            shit(oshibka);
                            oshibka = 0;
                            return;
                        }
                        if((a < 1 && a != 0 && a> 0) && b < 0)
                        {
                            oshibka = 4;
                            shit(oshibka);
                            oshibka = 0;
                            return;
                        }
                        head = push(head,pow(b,a),0);
                        break;
                    case '!': head = push(head,fact(b) + a,0);
                }

            }
            else {head = push(head,cur->numb,0);}
            cur = cur->next;
        }
        short out = 1;
        if (head->numb<=10000000000)
        {
        float test;
        test=head->numb;
        head->numb=test; // костыль
        }
        if (head->numb > 10000000000000000)
        {
            oshibka = 6;
            shit(oshibka);
            oshibka = 0;
            return;
        }
        while (float(int(head->numb * pow(10, out))) != float(head->numb * pow(10, out)))
        {
            out++;
        }


        if(oshibka == 0) ui->label->setText(QString::number(head->numb,'f',out));
        MainWindow::ui->tochka->setEnabled(true);
        if (ui->label->text().contains('.')) MainWindow::ui->tochka->setEnabled(false);
    }

void MainWindow::on_RC_clicked()
{
    QString string;
    int n;
    string = ui->label->text();
    n = ui->label->text().length();
    string.remove(n-1,1);
    ui->label->setText(string);
    MainWindow::ui->tochka->setEnabled(true);
}

void MainWindow::on_buttonpow_clicked()
{
    if (ui->label->text().size() >= 45)
    {
        gendalf window;
        window.setModal(true);
        window.exec();
        return;
    }
    ui->label->setText(ui->label->text() + "^");
    MainWindow::ui->tochka->setEnabled(true);
}

void MainWindow::on_faktorial_clicked()
{
    if (ui->label->text().size() >= 45)
    {
        gendalf window;
        window.setModal(true);
        window.exec();
        return;
    }
    int n;
    n = ui->label->text().length();
    QString subString;
    ui->label->setText(ui->label->text() + "!");
    MainWindow::ui->tochka->setEnabled(true);
}
