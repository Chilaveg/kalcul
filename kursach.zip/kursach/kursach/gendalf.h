#ifndef GENDALF_H
#define GENDALF_H

#include <QDialog>

namespace Ui {
class gendalf;
}

class gendalf : public QDialog
{
    Q_OBJECT

public:
    explicit gendalf(QWidget *parent = 0);
    ~gendalf();

private:
    Ui::gendalf *ui;
};

#endif // GENDALF_H
